package com.kalaiyarasan.to_do_list;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.ViewHolder> {

    private ArrayList<TaskModel> taskList;
    private OnTaskCompleteListener listener;
    private boolean isCompletedList; // Flag to check if this is the completed task list

    public TaskAdapter(ArrayList<TaskModel> taskList, OnTaskCompleteListener listener, boolean isCompletedList) {
        this.taskList = taskList;
        this.listener = listener;
        this.isCompletedList = isCompletedList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.task_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TaskModel task = taskList.get(position);
        holder.taskName.setText(task.getTaskName());
        holder.dueDate.setText("Due: " + task.getDueDate());

        // Hide the checkbox if it's the completed task list
        if (isCompletedList) {
            holder.checkBox.setVisibility(View.GONE);
        } else {
            holder.checkBox.setVisibility(View.VISIBLE);
            holder.checkBox.setChecked(task.isCompleted());

            // Handle task completion
            holder.checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked && listener != null) {
                    listener.onTaskComplete(task);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView taskName, dueDate;
        CheckBox checkBox;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            taskName = itemView.findViewById(R.id.taskName);
            dueDate = itemView.findViewById(R.id.dueDate);
            checkBox = itemView.findViewById(R.id.checkBox);
        }
    }

    public interface OnTaskCompleteListener {
        void onTaskComplete(TaskModel task);
    }
}
