package com.kalaiyarasan.to_do_list;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements TaskAdapter.OnTaskCompleteListener {

    private EditText editTextTask;
    private Button buttonAdd, buttonSelectDate;
    private RecyclerView recyclerViewTasks, recyclerViewCompleted;
    private TaskAdapter taskAdapter, completedTaskAdapter;
    private ArrayList<TaskModel> taskList, completedTaskList;
    private String selectedDueDate = "No Due Date"; // Default value if not selected

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Views
        editTextTask = findViewById(R.id.editTextTask);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonSelectDate = findViewById(R.id.buttonSelectDate);
        recyclerViewTasks = findViewById(R.id.recyclerViewTasks);
        recyclerViewCompleted = findViewById(R.id.recyclerViewCompleted);

        // Initialize Lists
        taskList = new ArrayList<>();
        completedTaskList = new ArrayList<>();

        // Setup RecyclerView for Pending Tasks
        taskAdapter = new TaskAdapter(taskList, this, false); // false = Show CheckBox
        recyclerViewTasks.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewTasks.setAdapter(taskAdapter);

        // Setup RecyclerView for Completed Tasks
        completedTaskAdapter = new TaskAdapter(completedTaskList, this, true); // true = Hide CheckBox
        recyclerViewCompleted.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewCompleted.setAdapter(completedTaskAdapter);

        // Add Task Button Click Listener
        buttonAdd.setOnClickListener(v -> addTask());

        // Select Due Date Button Click Listener
        buttonSelectDate.setOnClickListener(v -> showDatePicker());
    }

    // Method to Add a New Task
    private void addTask() {
        String taskText = editTextTask.getText().toString().trim();

        if (taskText.isEmpty()) {
            Toast.makeText(this, "Please enter a task!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Add new task with selected due date
        taskList.add(new TaskModel(taskText, selectedDueDate, false));

        taskAdapter.notifyDataSetChanged();

        // Reset input field
        editTextTask.setText("");
        selectedDueDate = "No Due Date"; // Reset due date
    }

    // Method to Show Date Picker Dialog
    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, year1, month1, dayOfMonth) -> {
            selectedDueDate = dayOfMonth + "/" + (month1 + 1) + "/" + year1;
            Toast.makeText(MainActivity.this, "Due Date: " + selectedDueDate, Toast.LENGTH_SHORT).show();
        }, year, month, day);

        datePickerDialog.show();
    }

    // Method to Handle Task Completion
    @Override
    public void onTaskComplete(TaskModel task) {
        taskList.remove(task);
        completedTaskList.add(task);
        taskAdapter.notifyDataSetChanged();
        completedTaskAdapter.notifyDataSetChanged();
    }
}
