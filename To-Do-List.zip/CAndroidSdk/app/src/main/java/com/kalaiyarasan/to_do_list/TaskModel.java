package com.kalaiyarasan.to_do_list;

public class TaskModel {
    private String taskName;
    private String dueDate;
    private boolean isCompleted;

    // Constructor
    public TaskModel(String taskName, String dueDate, boolean isCompleted) {
        this.taskName = taskName;
        this.dueDate = dueDate;
        this.isCompleted = isCompleted;
    }

    // Getter methods
    public String getTaskName() {
        return taskName;
    }

    public String getDueDate() {
        return dueDate;
    }

    public boolean isCompleted() {
        return isCompleted;
    }

    // Setter methods
    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public void setCompleted(boolean completed) {
        isCompleted = completed;
    }
}
